package com.example.tasque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TasqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
