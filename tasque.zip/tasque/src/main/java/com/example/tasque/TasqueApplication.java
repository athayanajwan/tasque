package com.example.tasque;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TasqueApplication {

	public static void main(String[] args) {
		SpringApplication.run(TasqueApplication.class, args);
	}

}
