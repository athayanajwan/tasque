/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author regianyogaswara
 */
package com.example.tasque.dto;

import com.example.tasque.model.NotificationType;

public class NotificationDTO {

    private String recipientId;
    private String message;
    private NotificationType type;

    // Constructor default
    public NotificationDTO() {}

    // Getter & Setter
    public String getRecipientId() {
        return recipientId;
    }

    public void setRecipientId(String recipientId) {
        this.recipientId = recipientId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public NotificationType getType() {
        return type;
    }

    public void setType(NotificationType type) {
        this.type = type;
    }
}


