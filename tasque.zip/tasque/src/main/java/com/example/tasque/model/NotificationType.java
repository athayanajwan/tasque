/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.tasque.model;

/**
 *
 * @author regianyogaswara
 */

public enum NotificationType {
    TASK_ASSIGNED,
    DEADLINE_REMINDER,
    COMMENT_ADDED
}

